i = 0;
var t = new Array("aqua", "blue", "gray", "green", "lime", "maroon", "navy", "olive", "purple", "red", "silver", "teal", "yellow", "white");

setInterval('change()',500);

function change(){
	if(i>15){
		i=0;
    }
	document.body.style.backgroundColor = t[i];
	i=i+1;
}

var img_diapo = new Array("bigfernand.jpg", "blend.jpg", "burger1.jpg", "pny.jpg", "gumboyaya.jpg", "ruisseau.jpg", "signature.jpg")

setInterval('diapo()', 500);

function diapo(){
	if(i>6){
		i=0;
	}
	document.getElementById("diapo").src = img_diapo[i];
	i=i+1;
}