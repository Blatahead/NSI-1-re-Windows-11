function entierAleatoire(min, max){
 return Math.floor(Math.random() * (max - min + 1)) + min;
}

function boutonCouleur(){
    var tabcolor = ["#35acda", "#bedede", "#c42f50", "#aca393", "#ff0000", "#78edb2", "#ffbe46"];
    var nb = entierAleatoire(0, 7);
    document.body.style.backgroundColor = tabcolor[nb];
}

function boutonPolice(){
    var tabpolice = ["Impact,Charcoal,sans-serif", "'Courier New', Courier, monospace", "'Times New Roman', Times, serif", "'Franklin Gothic Medium'", "'Arial Narrow', Arial, sans-serif"]
    var nb = entierAleatoire(0, 4);
    document.body.style.fontFamily = tabpolice[nb];
}
function changeImg(nom){
    document.getElementById("burgerimg").src = nom;
}

function logo_out(){
    document.getElementById("logo_burger").src = 'burger1.jpg';
}

function logo_in(){
    document.getElementById("logo_burger").src = 'hamdog.jpg';
}

function carte(){
    if (document.getElementsByTagName("iframe")[0].style.display == 'block') {
        document.getElementsByTagName("iframe")[0].style.display = 'none';
        document.getElementsByClassName("text_btn_map")[0].innerHTML = "Afficher la carte";
    } else {
        document.getElementsByTagName("iframe")[0].style.display = 'block';
        document.getElementsByClassName("text_btn_map")[0].innerHTML = "Masquer la carte";
    }
}